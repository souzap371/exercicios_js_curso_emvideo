var c = 1
do {
    console.log(`Passo ${c}`)
    c++
} while (c <= 5)
/*
var c = 1
while (c <= 3) {
    console.log(`Passo ${c}`)
    c++

*/



/* console.log('Tudo bem ?')
console.log('Tudo bem ?')
console.log('Tudo bem ?')
console.log('Tudo bem ?')
console.log('Tudo bem ?')
console.log('Tudo bem ?')
*/