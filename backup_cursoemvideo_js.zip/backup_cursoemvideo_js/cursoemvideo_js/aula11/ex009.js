var pais = 'Brasil'
console.log(`Vivendo em ${pais}`)
if (pais == 'Brasil') { //Condição composta
    console.log('Brasileiro!')
} else {
    console.log('Estrangeiro!')
}