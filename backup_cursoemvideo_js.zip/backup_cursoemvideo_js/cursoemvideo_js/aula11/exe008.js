var vel = 68.2
console.log(`Avelocidade do seu carro é ${vel}Km/h`)
if (vel > 60) { //Condição simples
    console.log(`Você ultrapassou a velocidade permitida. MULTADO!`)
}
console.log(`Dirija sempre usando cinto de segurnaça!`)