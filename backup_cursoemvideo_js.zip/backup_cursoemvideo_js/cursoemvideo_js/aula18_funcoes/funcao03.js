let v = function (x) {
    return x * 2
}

console.log(v(5))