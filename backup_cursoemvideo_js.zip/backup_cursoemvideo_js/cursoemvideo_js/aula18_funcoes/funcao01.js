function parimpar(n) {
    if (n % 2 == 0) {
        return 'Par!'
    } else {
        return 'Impar!'
    }
}
let res = parimpar(4)
console.log(res)

//ou console.log(parimpar(4))