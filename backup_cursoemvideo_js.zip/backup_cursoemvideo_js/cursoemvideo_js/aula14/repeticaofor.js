console.log('Vai começar...')

for (var c = 1; c <= 5; c++) {
    console.log(`Passo ${c}`)

}
console.log('Fim.!')