//Aplicação de valores dentro de um vetor "num"

let num = [5, 8, 2, 9, 3]
//console.log(num[0])                                   //Mostra o valor do elemento dentro de indice [0]
//console.log(num[1])                                   //Mostra o valor do elemento dentro de indice [1]
//console.log(num[2])                                   //Mostra o valor do elemento dentro de indice [2]
//console.log(num[3])                                   //Mostra o valor do elemento dentro de indice [3]
//console.log(num[4])                                   //Mostra o valor do elemento dentro de indice [4]
//console.log(num[5])                                   //Mostra o valor do elemento dentro de indice [5]
//
//Para evitar ter que chamar todos os valores, substituimos por "for"


num.push(1)                                             //Adiciona um indice ao final e adiociona o valor de elemento 1
num.sort()                                              //Organiza de forma crescente os valores dos elementos dos vetores
console.log(num)
console.log(`Nosso vetor tem ${num.length} posições`)   //Mostra a quantidade de posições de um Vetor ou Array
console.log(`O primeiro valor do vetor é ${num[0]}`)    //Mostra o primeiro valor de um Vetor que ´´e o de posição [0]

let pos = num.indexOf(8)
if (pos == -1) {
    console.log(`O valor não foi encontrado!`)
} else {
    console.log(`O valor está na posição ${pos}`)
}


