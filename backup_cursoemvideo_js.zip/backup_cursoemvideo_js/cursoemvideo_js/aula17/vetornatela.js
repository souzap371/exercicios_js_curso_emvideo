//Ativar com f8 a ferramenta do node dentro do Visual Studio

let valores = [8, 1, 7, 4, 2, 9]

console.log(valores)
/*
//Forma bruta de mostrar valor a valor de cada indice de um Vetor
console.log(valores[0])
console.log(valores[1])
console.log(valores[2])
console.log(valores[3])
console.log(valores[4])
console.log(valores[5])
*/
//Forma Simplificada de mostrar valor a valor de cada indice de um Vetor
/*
for (let pos = 0; pos < valores.length; pos++) {
    console.log(`A posição${pos} tem o valor ${valores[pos]}`)
}

//Forma mais Simplificada ainda de mostrar valor a valor de cada indice de um Vetor
for (let pos in valores) {
    //console.log(`${valores[pos]}`)
    console.log(`Aposição ${pos} tem o valor ${valores[pos]}`)
}
*/